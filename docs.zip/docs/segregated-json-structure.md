# Segregated JSON Structure Implementation

## 🎯 **Overview**

The JSON constructor now generates the **exact segregated structure** from your `learn.json` file with triggers and actions separated into their respective arrays, plus the layout object for node alignment storage.

## 📋 **Correct Segregated Structure**

```json
{
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [
    {
      "type": "ElementFormTrigger",
      "config": {
        "child": "send-email-action-1",
        "options": {
          "key": "form-filled",
          "automation_uid": "backend-will-give",
          "form_builder_uid": "6570a835dbfc0",
          "init": true
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "actions": [
    {
      "id": "send-email-action-1",
      "type": "ElementAction",
      "config": {
        "type": "ElementAction",
        "options": {
          "key": "send-email-action",
          "email_uid": "658aaa6b2c053",
          "fromName": "David Encoder",
          "emailSubject": "Welcome to our service!",
          "content": "Welcome message content...",
          "template": "true"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    },
    {
      "id": "send-whatsapp-action-2",
      "type": "ElementWhatsApp",
      "config": {
        "type": "ElementWhatsApp",
        "options": {
          "key": "send_whatsapp_message",
          "wa_template_id": "134",
          "messageContent": "Hello from WhatsApp!",
          "device": "device1",
          "init": true
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "layout": {
    "node": [
      {
        "id": "trigger-1",
        "type": "form-trigger",
        "position": { "x": 100, "y": 100 },
        "data": {
          "label": "Form Submitted",
          "icon": undefined,
          "color": undefined,
          "backendId": undefined,
          "submitted": false
        }
      },
      {
        "id": "send-email-action-1",
        "type": "send-email-action",
        "position": { "x": 300, "y": 100 },
        "data": {
          "label": "Send Email",
          "submitted": true
        }
      }
    ],
    "edges": [
      {
        "id": "edge-1",
        "source": "trigger-1",
        "target": "send-email-action-1",
        "type": "default",
        "animated": false
      }
    ]
  }
}
```

## 🔧 **Implementation Details**

### **1. Trigger Processing**
```typescript
// ✅ Separate trigger nodes
const triggerNodes = nodes.filter(node => 
  node.type === 'trigger' || node.type.includes('trigger')
);

// ✅ Build triggers array
const triggers = triggerNodes.map(triggerNode => {
  const nextEdge = edges.find(edge => edge.source === triggerNode.id);
  const nextNode = nextEdge ? nodes.find(n => n.id === nextEdge.target) : null;
  
  return {
    type: this.mapNodeTypeToBackend(triggerNode.type),
    config: {
      child: nextNode ? nextNode.id : null, // Frontend node ID
      options: {
        key: this.getNodeKey(triggerNode.type),
        automation_uid: 'backend-will-give',
        ...this.extractNodeConfig(triggerNode) // Configuration data
      },
      last_executed: null,
      evaluationResult: null
    }
  };
});
```

### **2. Action Processing**
```typescript
// ✅ Separate action nodes
const actionNodes = nodes.filter(node => 
  !node.type.includes('trigger')
);

// ✅ Build actions array
const actions = actionNodes.map(actionNode => {
  return {
    id: actionNode.id, // Frontend node ID
    type: this.mapNodeTypeToBackend(actionNode.type),
    config: {
      type: this.mapNodeTypeToBackend(actionNode.type),
      options: {
        key: this.getNodeKey(actionNode.type),
        ...this.extractNodeConfig(actionNode) // Configuration data
      },
      last_executed: null,
      evaluationResult: null
    }
  };
});
```

### **3. Layout Object**
```typescript
// ✅ Store node alignment for loading next time
const layout = {
  node: nodes.map(node => ({
    id: node.id,
    type: node.type,
    position: node.position, // x, y coordinates
    data: {
      label: node.data.label || 'Unnamed Node',
      icon: node.data.icon || undefined,
      color: node.data.color || undefined,
      backendId: node.data.backendId || undefined,
      submitted: node.data.submitted || false
    }
  })),
  edges: edges.map(edge => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
    type: edge.type || 'default',
    animated: edge.animated || false
  }))
};
```

## 📊 **Configuration Examples**

### **Email Action (Configured)**
```json
{
  "id": "email-action-123",
  "type": "ElementAction",
  "config": {
    "type": "ElementAction",
    "options": {
      "key": "send-email-action",
      "email_uid": "welcome_template",
      "fromName": "David Encoder",
      "emailSubject": "Welcome to our service!",
      "content": "Welcome message content...",
      "template": "true"
    },
    "last_executed": null,
    "evaluationResult": null
  }
}
```

### **SMS Action (Configured)**
```json
{
  "id": "sms-action-456",
  "type": "ElementSMS",
  "config": {
    "type": "ElementSMS",
    "options": {
      "key": "send-sms-action",
      "provider": "twilio",
      "messageContent": "Hello from SMS!",
      "senderName": "MyCompany"
    },
    "last_executed": null,
    "evaluationResult": null
  }
}
```

### **WhatsApp Action (Configured)**
```json
{
  "id": "whatsapp-action-789",
  "type": "ElementWhatsApp",
  "config": {
    "type": "ElementWhatsApp",
    "options": {
      "key": "send_whatsapp_message",
      "wa_template_id": "134",
      "messageContent": "Hello from WhatsApp!",
      "device": "device1",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  }
}
```

## 🔄 **Real-Time Flow**

### **Node Addition**
```
User adds SMS node
↓
Segregated JSON generated:
{
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [],
  "actions": [
    {
      "id": "sms-action-123",
      "type": "ElementSMS",
      "config": {
        "options": {
          "key": "send-sms-action"
        }
      }
    }
  ],
  "layout": {
    "node": [{ "id": "sms-action-123", "position": {...} }],
    "edges": []
  }
}
↓
POST /api/workflows with segregated JSON
```

### **Configuration Submission**
```
User configures SMS node
↓
setConfig({ smsConfig: {...}, submitted: true })
↓
Segregated JSON updated:
{
  "actions": [
    {
      "id": "sms-action-123",
      "config": {
        "options": {
          "key": "send-sms-action",
          "provider": "twilio",
          "messageContent": "Hello!",
          "senderName": "MyCompany"
        }
      }
    }
  ]
}
↓
PUT /api/workflows/{automation_id} with updated JSON
```

## 📋 **Console Output Example**

```
🚀 === CONSTRUCTING SEGREGATED JSON (LEARN.JSON FORMAT) === {
  nodes: 3,
  edges: 2,
  workflowName: "My workflow"
}

✅ === SEGREGATED JSON CONSTRUCTION COMPLETED === {
  timestamp: "2024-01-04T10:30:00.000Z",
  triggersCount: 1,
  actionsCount: 2,
  layoutNodes: 3,
  layoutEdges: 2,
  structure: "segregated (learn.json format)"
}

📋 === FINAL SEGREGATED JSON OUTPUT ===
{
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [
    {
      "type": "ElementFormTrigger",
      "config": {
        "child": "send-email-action-1",
        "options": {
          "key": "form-filled",
          "automation_uid": "backend-will-give",
          "form_builder_uid": "6570a835dbfc0",
          "init": true
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "actions": [
    {
      "id": "send-email-action-1",
      "type": "ElementAction",
      "config": {
        "type": "ElementAction",
        "options": {
          "key": "send-email-action",
          "email_uid": "658aaa6b2c053",
          "fromName": "David Encoder",
          "emailSubject": "Welcome!",
          "template": "true"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    },
    {
      "id": "send-whatsapp-action-2",
      "type": "ElementWhatsApp",
      "config": {
        "type": "ElementWhatsApp",
        "options": {
          "key": "send_whatsapp_message",
          "wa_template_id": "134",
          "init": true
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "layout": {
    "node": [
      {
        "id": "trigger-1",
        "type": "form-trigger",
        "position": { "x": 100, "y": 100 },
        "data": { "label": "Form Submitted", "submitted": false }
      },
      {
        "id": "send-email-action-1",
        "type": "send-email-action",
        "position": { "x": 300, "y": 100 },
        "data": { "label": "Send Email", "submitted": true }
      }
    ],
    "edges": [
      {
        "id": "edge-1",
        "source": "trigger-1",
        "target": "send-email-action-1",
        "type": "default",
        "animated": false
      }
    ]
  }
}
```

## 🎯 **Key Benefits**

1. **Segregated Structure**: Triggers and actions in separate arrays
2. **Layout Storage**: Node positions and edges stored for reloading
3. **Configuration Storage**: All form data in `options` objects
4. **Frontend ID Usage**: Uses actual React Flow node IDs
5. **Real-Time Updates**: Updates on every node/edge change
6. **Backend Ready**: Perfect format for automation processing

## 🚀 **Backend Integration**

```typescript
// Submit segregated JSON
POST /api/workflows
Body: {
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [...],
  "actions": [...],
  "layout": {...}
}

// Backend processes triggers and actions separately
// Returns automation_id for tracking
{ "automation_id": "auto_123" }
```

This implementation now generates the **exact segregated structure** from your learn.json with triggers/actions separated and layout storage for node alignment! 🎯✨
