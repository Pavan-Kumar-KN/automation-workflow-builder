# Learn.json Format Flow Documentation

## 🎯 **Overview**

The workflow builder now generates JSON in the **exact format** specified in `learn.json`. This enables seamless backend integration with automation ID tracking and configuration storage in the `options` object.

## 📋 **Learn.json Format Structure**

```json
{
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [
    {
      "type": "ElementFormTrigger",
      "config": {
        "child": "send-email-action",
        "options": {
          "key": "send-email-action",
          "automation_uid": "backend-will-give"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "actions": [
    {
      "id": "send-email-action",
      "type": "ElementFormTrigger",
      "config": {
        "type": "ElementMailAction",
        "options": {
          "key": "send-email-action"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "layout": {
    "node": [],
    "edges": []
  }
}
```

## 🔄 **Real-Time Flow with Learn.json Format**

```mermaid
sequenceDiagram
    participant User
    participant UI
    participant WorkflowBuilder
    participant JSONConstructor
    participant Backend
    participant Console

    Note over User,Console: REAL-TIME LEARN.JSON FORMAT TRACKING

    User->>UI: Add Node
    UI->>WorkflowBuilder: setNodes([...nodes, newNode])
    WorkflowBuilder->>JSONConstructor: BackendJSONConstructor.construct()
    JSONConstructor->>Console: Log: "JSON MATCHING LEARN.JSON FORMAT"
    JSONConstructor->>Console: Log: Learn.json structure
    JSONConstructor->>Backend: POST /api/workflows (learn.json format)
    Backend->>WorkflowBuilder: Return { automation_id: "auto_123" }
    WorkflowBuilder->>WorkflowBuilder: Update node.data.backendId

    User->>UI: Configure Node (Submit Config)
    UI->>WorkflowBuilder: updateNodeData(nodeId, { submitted: true, config })
    WorkflowBuilder->>JSONConstructor: BackendJSONConstructor.construct()
    JSONConstructor->>Console: Log: "Config stored in options"
    JSONConstructor->>Backend: PUT /api/workflows/auto_123 (updated config)
    Backend->>WorkflowBuilder: Return { status: "updated" }
```

## 📊 **Configuration Storage in Options**

### **Before Configuration (Node Added)**
```json
{
  "actions": [
    {
      "id": "sms-action-1",
      "type": "ElementSmsAction",
      "config": {
        "type": "ElementSmsAction",
        "options": {
          "key": "send-sms-action"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ]
}
```

### **After Configuration (User Submits Config)**
```json
{
  "actions": [
    {
      "id": "sms-action-1", 
      "type": "ElementSmsAction",
      "config": {
        "type": "ElementSmsAction",
        "options": {
          "key": "send-sms-action",
          "messageContent": "Hello from SMS!",
          "selectedProvider": "twilio",
          "senderName": "MyCompany"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ]
}
```

## 🔧 **Configuration Data Extraction**

### **SMS Configuration Example**
```typescript
// User submits SMS configuration
const smsConfig = {
  messageContent: "Hello from SMS!",
  senderName: "MyCompany"
};

const nodeData = {
  selectedProvider: "twilio",
  smsConfig: smsConfig,
  submitted: true
};

// JSON Constructor extracts and stores in options
const options = {
  key: "send-sms-action",
  provider: "twilio",
  senderName: "MyCompany", 
  messageContent: "Hello from SMS!"
};
```

### **Email Configuration Example**
```typescript
// User submits email configuration
const emailConfig = {
  fromName: "David Encoder",
  emailSubject: "Welcome!",
  content: "Welcome to our service..."
};

const nodeData = {
  selectedTemplate: "welcome-template",
  emailConfig: emailConfig,
  submitted: true
};

// JSON Constructor extracts and stores in options
const options = {
  key: "send-email-action",
  email_uid: "welcome-template",
  fromName: "David Encoder",
  emailSubject: "Welcome!",
  content: "Welcome to our service..."
};
```

## 🚀 **Backend Integration Points**

### **1. Node Addition (Real-Time)**
```typescript
// When user adds node
const json = BackendJSONConstructor.construct(nodes, edges, workflowName);

// POST to backend
POST /api/workflows
Body: {
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [...],
  "actions": [
    {
      "id": "new-action-1",
      "type": "ElementSmsAction",
      "config": {
        "options": {
          "key": "send-sms-action"
        }
      }
    }
  ],
  "layout": { "node": [...], "edges": [...] }
}

// Backend Response
{
  "automation_id": "auto_123",
  "status": "created"
}

// Update frontend
node.data.backendId = "auto_123"
```

### **2. Configuration Submission**
```typescript
// When user submits node configuration
const { submitConfigToBackend } = useWorkflowJSON();

// In node config component (e.g., SmsConfig)
const handleSubmit = async () => {
  // Update node data with configuration
  setConfig({
    ...config,
    selectedProvider: "twilio",
    smsConfig: { messageContent: "Hello!" },
    submitted: true
  });
  
  // Submit to backend with automation_id
  await submitConfigToBackend(nodeId, node.data.backendId);
};

// PUT to backend
PUT /api/workflows/auto_123
Body: {
  "name": "take-from-state",
  "actions": [
    {
      "id": "auto_123",
      "config": {
        "options": {
          "key": "send-sms-action",
          "provider": "twilio",
          "messageContent": "Hello!"
        }
      }
    }
  ]
}
```

## 📋 **Console Output Examples**

### **Node Addition**
```
🔧 Node Operation Detected: { changes: [{ type: 'add', id: 'sms-123' }] }
🚀 === REAL-TIME JSON CONSTRUCTION ===
📊 Real-time Node Analysis: { totalNodes: 1, pendingBackendSync: 1 }
✅ === JSON MATCHING LEARN.JSON FORMAT === {
  structure: "learn.json format",
  triggers: 0,
  actions: 1,
  layout: { nodes: 1, edges: 0 }
}
📋 === FINAL JSON OUTPUT (LEARN.JSON FORMAT) ===
{
  "name": "take-from-state",
  "user_id": "backend-will-give",
  "triggers": [],
  "actions": [
    {
      "id": "sms-123",
      "type": "ElementSmsAction",
      "config": {
        "type": "ElementSmsAction",
        "options": {
          "key": "send-sms-action"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ],
  "layout": {
    "node": [
      {
        "id": "sms-123",
        "type": "send-sms-action",
        "position": { "x": 100, "y": 100 },
        "data": { ... }
      }
    ],
    "edges": []
  }
}
```

### **Configuration Submission**
```
🔧 === CONFIG SUBMISSION TO BACKEND === {
  nodeId: "sms-123",
  automationId: "auto_123",
  timestamp: "2024-01-04T10:30:00.000Z",
  json: { ... }
}

📊 Real-time Node Analysis: {
  nodeTypes: [
    { id: "sms-123", type: "send-sms-action", hasConfig: true, backendId: "auto_123" }
  ],
  configuredNodes: 1
}

📋 === FINAL JSON OUTPUT (LEARN.JSON FORMAT) ===
{
  "name": "take-from-state",
  "actions": [
    {
      "id": "auto_123",
      "type": "ElementSmsAction", 
      "config": {
        "type": "ElementSmsAction",
        "options": {
          "key": "send-sms-action",
          "provider": "twilio",
          "senderName": "MyCompany",
          "messageContent": "Hello from SMS!"
        },
        "last_executed": null,
        "evaluationResult": null
      }
    }
  ]
}

✅ Config update response: { status: "updated" }
```

## 🎯 **Key Features**

### **1. Exact Learn.json Format** ✅
- Matches your `learn.json` structure exactly
- `config` object with `options` inside
- `layout.node` and `layout.edges` (not `nodes`)
- String IDs for actions, automation_uid handling

### **2. Configuration Storage** ✅
- All form data stored in `options` object
- Real-time extraction from node.data
- Proper key mapping for different node types

### **3. Real-Time Backend Sync** ✅
- JSON generated on every node operation
- Immediate backend submission
- Automation ID tracking and updates

### **4. Two-Phase Flow** ✅
- **Phase 1**: Node addition → Basic JSON → Get automation_id
- **Phase 2**: Config submission → Updated JSON with options → Update automation

### **5. Complete Visibility** ✅
- Every operation logged with timestamps
- JSON structure validation
- Backend response tracking

## 🔧 **Usage in Components**

### **In Node Configuration Components**
```typescript
import { useWorkflowJSON } from '@/hooks/useWorkflowJSON';

const SmsConfig = ({ config, setConfig }) => {
  const { submitConfigToBackend } = useWorkflowJSON();
  
  const handleSubmit = async () => {
    // Update node configuration
    setConfig({
      ...config,
      selectedProvider: "twilio",
      smsConfig: { messageContent: "Hello!" },
      submitted: true
    });
    
    // Submit to backend if node has automation_id
    if (config.backendId) {
      await submitConfigToBackend(config.id, config.backendId);
    }
  };
};
```

### **In WorkflowBuilder**
```typescript
import { useWorkflowJSON } from '@/hooks/useWorkflowJSON';

const WorkflowBuilder = () => {
  const { generateJSON, submitToBackend } = useWorkflowJSON();
  
  // JSON is automatically generated on every node/edge change
  // and logged in learn.json format
};
```

This implementation provides complete compatibility with your learn.json format while maintaining real-time backend synchronization and comprehensive logging! 🎯✨
