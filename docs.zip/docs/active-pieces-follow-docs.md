# ActivePieces-Style Workflow Builder Documentation

## Overview

This document outlines how our workflow builder follows the ActivePieces design patterns and implementation details for creating nodes, edges, and user interactions.

## Table of Contents

1. [Node Architecture](#node-architecture)
2. [Edge Design](#edge-design)
3. [User Interactions](#user-interactions)
4. [JSON Structure](#json-structure)
5. [State Management](#state-management)
6. [Component Structure](#component-structure)

## Node Architecture

### Node Types

Our workflow builder implements three main node types following ActivePieces patterns:

#### 1. Trigger Nodes
- **Purpose**: Starting points of workflows
- **Design**: Rounded rectangles with step numbers and icons
- **Behavior**: 
  - Default trigger: Opens trigger selection modal on body click
  - Configured trigger: Opens configuration panel on body click
  - 3-dots menu: Shows "Replace Trigger" (only for configured triggers)

```typescript
interface TriggerNodeProps {
  data: {
    label: string;
    id: string;
    icon?: keyof typeof LucideIcons;
    isConfigured?: boolean;
    openTriggerModal?: () => void;
  };
  isSelected?: boolean;
  onReplaceTrigger?: () => void;
  onOpenConfig?: () => void;
}
```

#### 2. Action Nodes
- **Purpose**: Operations performed in the workflow
- **Design**: Similar to triggers but with action-specific styling
- **Behavior**:
  - Body click: Opens configuration panel
  - 3-dots menu: Shows "Delete Action"

```typescript
interface ActionNodeProps {
  data: {
    label: string;
    id: string;
    icon?: keyof typeof LucideIcons;
    color?: string;
  };
  isSelected?: boolean;
  onDelete?: () => void;
}
```

#### 3. Condition Nodes
- **Purpose**: Decision points with branching logic
- **Design**: Router-style with curved branch paths
- **Behavior**: Supports true/false branching with visual flow indicators

### Node Styling

Following ActivePieces design principles:

```css
/* Base node styling */
.workflow-node {
  background: white;
  border-radius: 8px;
  border: 2px solid #e5e7eb;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 24px;
  width: 360px;
  cursor: pointer;
  transition: all 200ms;
}

.workflow-node:hover {
  border-color: #d1d5db;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.workflow-node.selected {
  border-color: #3b82f6;
  ring: 2px solid #bfdbfe;
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}
```

### Icon System

Icons are handled dynamically with proper fallbacks:

```typescript
const IconComponent = React.useMemo(() => {
  if (!data.icon) {
    return LucideIcons.Phone as React.ComponentType<any>;
  }

  if (typeof data.icon === 'string') {
    return (LucideIcons[data.icon as keyof typeof LucideIcons] || LucideIcons.Phone) as React.ComponentType<any>;
  }

  if (typeof data.icon === 'function') {
    return data.icon as React.ComponentType<any>;
  }

  return LucideIcons.Phone as React.ComponentType<any>;
}, [data.icon]);
```

## Edge Design

### Edge Creation Strategy

Edges are automatically created when nodes are added to maintain proper workflow connections:

```typescript
// Node addition with automatic edge creation
const handleNodeSelection = useCallback((nodeType: string, nodeData: NodeData) => {
  const newNode: Node = {
    id: `${nodeType}-${Date.now()}`,
    type: nodeType,
    position: { x: 0, y: 0 },
    data: { ...nodeData, isConfigured: false },
  };

  setNodes((nds) => {
    const newNodes = [...nds, newNode];
    
    // Create edge from previous node to new node
    if (nds.length > 0) {
      const previousNode = nds[nds.length - 1];
      const newEdge = {
        id: `edge-${previousNode.id}-${newNode.id}`,
        source: previousNode.id,
        target: newNode.id,
        type: 'smoothstep',
        animated: false,
      };
      
      setEdges((eds) => [...eds, newEdge]);
    }
    
    return newNodes;
  });
}, [setNodes, setEdges]);
```

### Edge Styling

Following ActivePieces visual design:

```typescript
const defaultEdgeOptions = {
  style: { strokeWidth: 2, stroke: '#6366f1' },
  type: 'smoothstep',
  animated: false,
};
```

### Edge Management

- **Node Insertion**: Automatically reconnects edges when inserting nodes between existing ones
- **Node Deletion**: Removes associated edges and reconnects remaining nodes
- **Condition Branching**: Supports multiple output edges for conditional logic

## User Interactions

### Click Behaviors

#### Trigger Nodes
1. **Default Trigger Body Click**: Opens trigger selection modal
2. **Configured Trigger Body Click**: Opens configuration panel
3. **3-Dots Menu**: Shows "Replace Trigger" (only for configured triggers)

#### Action Nodes
1. **Body Click**: Opens configuration panel
2. **3-Dots Menu**: Shows "Delete Action"

#### Plus Buttons
- **Between Nodes**: Inserts new action at specific position
- **End of Flow**: Adds new action to end of workflow

### Modal System

#### Trigger Selection Modal
```typescript
<TriggerCategoryModal
  isOpen={showTriggerModal}
  onClose={() => setShowTriggerModal(false)}
  onSelectTrigger={handleTriggerSelection}
/>
```

#### Action Selection Modal
```typescript
<ActionCategoryModal
  isOpen={showActionModal}
  onClose={() => setShowActionModal(false)}
  onSelectAction={handleActionSelection}
/>
```

### Configuration Panels

Side panels that slide in from the right for node configuration:

```typescript
{selectedNode && (
  <div className="fixed inset-x-0 bottom-0 h-1/2 z-50 md:relative md:w-[32rem] lg:w-[36rem]">
    <NodeConfigPanel
      node={selectedNode}
      onClose={() => setSelectedNode(null)}
      onUpdate={handleNodeUpdate}
    />
  </div>
)}
```

## JSON Structure

### Backend JSON Format

Following the required backend structure:

```typescript
interface BackendWorkflowJSON {
  name: string;
  user_id: string;
  triggers: BackendTrigger[];
  actions: BackendAction[];
}

interface BackendTrigger {
  type: string;
  config: {
    child: string | null; // Next node ID
    options: Record<string, any>;
    last_executed: null;
    evaluationResult: null;
  };
}

interface BackendAction {
  id: string;
  type: string;
  config: {
    child: string | null; // Next node ID
    type: string;
    options: Record<string, any>;
    last_executed: null;
    evaluationResult: null;
  };
}
```

### JSON Generation

Real-time JSON construction on every node/edge change:

```typescript
const actions = actionNodes.map(actionNode => {
  const nextEdge = edges.find(edge => edge.source === actionNode.id);
  const nextNode = nextEdge ? nodes.find(n => n.id === nextEdge.target) : null;

  return {
    id: actionNode.id,
    type: this.mapNodeTypeToBackend(actionNode.type),
    config: {
      child: nextNode ? nextNode.id : null, // ✅ Proper child linking
      type: this.mapNodeTypeToBackend(actionNode.type),
      options: {
        key: this.getNodeKey(actionNode.type),
        ...this.extractNodeConfig(actionNode)
      },
      last_executed: null,
      evaluationResult: null
    }
  };
});
```

## State Management

### Zustand Store Structure

```typescript
interface WorkflowState {
  // Core workflow state
  selectedNode: Node | null;
  workflowName: string;
  isActive: boolean;
  nodes: Node[];
  edges: Edge[];
  
  // Actions
  setNodes: (nodes: Node[] | ((prev: Node[]) => Node[])) => void;
  setEdges: (edges: Edge[] | ((prev: Edge[]) => Edge[])) => void;
  setSelectedNode: (node: Node | null) => void;
}
```

### Real-time Updates

JSON is automatically generated and logged on every change:

```typescript
useEffect(() => {
  if (nodes.length > 0) {
    const json = generateJSON();
    console.log('🔄 Current Workflow JSON:', json);
  }
}, [nodes.length, generateJSON]);
```

## Component Structure

### Main Components

1. **WorkflowBuilder**: Main container component
2. **SimpleWorkflowCanvas**: Renders the workflow nodes in sequence
3. **WorkflowHeader**: Contains workflow controls (Save, Execute, Reset)
4. **NodeConfigPanel**: Side panel for node configuration
5. **TriggerCategoryModal**: Modal for trigger selection
6. **ActionCategoryModal**: Modal for action selection

### Node Components

1. **TriggerNode**: Handles trigger display and interactions
2. **ActionNode**: Handles action display and interactions  
3. **ConditionNode**: Handles conditional branching logic

### Data Flow

```
User Action → WorkflowBuilder → SimpleWorkflowCanvas → Node Components
     ↓
State Update (Zustand) → JSON Generation → Backend Sync
```

## Key Features

### Reset Functionality
- **Reset Button**: Clears entire workflow and returns to default state
- **Confirmation Dialog**: Prevents accidental resets
- **Clean State**: Removes all nodes except default trigger

### Icon Processing
- **Dynamic Loading**: Icons are processed from component references to string names
- **Fallback System**: Graceful degradation when icons are missing
- **Color Support**: Icons inherit colors from node configuration

### Edge Animation
- **Smooth Transitions**: Uses smoothstep edge type for clean curves
- **No Animation**: Static edges for better performance
- **Auto-reconnection**: Smart edge management during node operations

## Advanced Implementation Details

### Node Color System

Each node type has its own color scheme following ActivePieces patterns:

```typescript
// Trigger color extraction
const getIconColors = () => {
  if (!data.isConfigured) {
    return {
      bgColor: 'bg-gray-100',
      textColor: 'text-gray-600'
    };
  }

  if (data.color) {
    const colorMatch = data.color.match(/bg-(\w+)-\d+/);
    if (colorMatch) {
      const baseColor = colorMatch[1];
      return {
        bgColor: `bg-${baseColor}-100`,
        textColor: `text-${baseColor}-600`
      };
    }
  }

  return {
    bgColor: 'bg-red-100',
    textColor: 'text-red-600'
  };
};
```

### Action Color Implementation

Actions use dynamic color classes:

```typescript
// Action nodes use color directly from data
<IconComponent className={`${data.color}`} />
```

### Categorized Data Structure

#### Triggers
```typescript
export const categorizedTriggers: TriggerCategory[] = [
  {
    id: 'form-triggers',
    name: 'Forms',
    icon: Zap,
    description: 'Triggers based on form interactions',
    color: 'bg-blue-50 border-blue-200',
    triggers: [
      {
        id: 'form-submitted-trigger',
        label: 'Forms',
        icon: Zap,
        description: 'Triggers when any form is submitted',
        color: 'bg-blue-50 border-blue-200'
      }
    ]
  }
];
```

#### Actions
```typescript
export const categorizedActions: ActionCategory[] = [
  {
    id: 'communication-actions',
    name: 'Communication',
    icon: Mail,
    description: 'Send messages and notifications',
    color: 'bg-blue-50 border-blue-200',
    actions: [
      {
        id: 'send-email-action',
        label: 'Send Email',
        icon: Mail,
        description: 'Send an email to contacts',
        color: 'bg-blue-50 border-blue-200'
      }
    ]
  }
];
```

### Configuration System

Each node type has dedicated configuration components:

#### Form Trigger Configuration
```typescript
const FormConfig: React.FC<ConfigComponentProps> = ({ config, setConfig }) => {
  const [forms, setForms] = useState([]);
  const [selectedForm, setSelectedForm] = useState('');

  // Fetch available forms
  const fetchProductForms = async () => {
    // API call to get forms
    setForms(['Product Enquiry Form 1', 'Product Enquiry Form 2']);
  };

  return (
    <div className="space-y-4">
      <Select value={selectedForm} onValueChange={setSelectedForm}>
        <SelectTrigger>
          <SelectValue placeholder="Select the form from the list" />
        </SelectTrigger>
        <SelectContent>
          {forms.map((form, index) => (
            <SelectItem key={index} value={form}>
              {form}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};
```

### Error Handling and Validation

#### Icon Processing with Fallbacks
```typescript
const handleActionSelect = (action: any) => {
  const processedAction = {
    ...action,
    icon: typeof action.icon === 'string'
      ? action.icon
      : (action.icon?.displayName || action.icon?.name || 'Phone')
  };
  onSelectAction(processedAction);
};
```

#### Node Validation
```typescript
// Warning indicators for unconfigured nodes
{!data.isConfigured && (
  <div className="text-orange-500">
    <LucideIcons.AlertTriangle className="w-4 h-4" />
  </div>
)}
```

### Performance Optimizations

#### Memoized Icon Components
```typescript
const IconComponent = React.useMemo(() => {
  // Icon processing logic
}, [data.icon]);
```

#### Efficient State Updates
```typescript
// Batch updates for node and edge changes
setNodes((nds) => {
  const newNodes = [...nds, newNode];
  // Update edges in same render cycle
  setEdges((eds) => [...eds, newEdge]);
  return newNodes;
});
```

### Accessibility Features

#### Keyboard Navigation
- Tab navigation through nodes
- Enter key to open configuration
- Escape key to close modals

#### Screen Reader Support
```typescript
<button
  aria-label={`Configure ${data.label} trigger`}
  onClick={handleClick}
>
  {/* Node content */}
</button>
```

### Mobile Responsiveness

#### Responsive Configuration Panel
```typescript
<div className="fixed inset-x-0 bottom-0 h-1/2 z-50 md:relative md:w-[32rem] lg:w-[36rem]">
  {/* Panel slides up on mobile, side panel on desktop */}
</div>
```

#### Touch-Friendly Interactions
- Larger touch targets for mobile
- Swipe gestures for panel dismissal
- Optimized modal sizing

## Workflow Execution Flow

### Node Processing Order

1. **Trigger Evaluation**: Check if trigger conditions are met
2. **Sequential Action Execution**: Process actions in order using `child` references
3. **Conditional Branching**: Handle true/false paths for condition nodes
4. **Error Handling**: Graceful failure recovery

### JSON-to-Execution Mapping

```typescript
// Backend processes workflow using child references
const executeWorkflow = (workflowJSON: BackendWorkflowJSON) => {
  // Start with triggers
  for (const trigger of workflowJSON.triggers) {
    if (evaluateTrigger(trigger)) {
      // Follow child chain
      let currentNodeId = trigger.config.child;

      while (currentNodeId) {
        const action = findActionById(currentNodeId);
        executeAction(action);
        currentNodeId = action.config.child; // Move to next node
      }
    }
  }
};
```

## Best Practices

### Code Organization

1. **Component Separation**: Each node type has its own component
2. **Data Normalization**: Consistent data structures across components
3. **Type Safety**: Full TypeScript coverage for all interfaces
4. **Error Boundaries**: Graceful error handling at component level

### State Management Guidelines

1. **Single Source of Truth**: Zustand store for all workflow state
2. **Immutable Updates**: Always create new objects/arrays
3. **Batch Updates**: Combine related state changes
4. **Persistence**: Auto-save workflow state to localStorage

### Performance Best Practices

1. **Memoization**: Use React.useMemo for expensive calculations
2. **Lazy Loading**: Load configuration components on demand
3. **Debounced Updates**: Prevent excessive re-renders
4. **Virtual Scrolling**: For large workflows (future enhancement)

### Testing Strategy

#### Unit Tests
```typescript
describe('TriggerNode', () => {
  it('should open trigger modal for default trigger', () => {
    const mockOpenModal = jest.fn();
    render(<TriggerNode data={{ label: 'Select Trigger', openTriggerModal: mockOpenModal }} />);

    fireEvent.click(screen.getByText('Select Trigger'));
    expect(mockOpenModal).toHaveBeenCalled();
  });
});
```

#### Integration Tests
```typescript
describe('Workflow Builder', () => {
  it('should create proper JSON structure', () => {
    // Add trigger and action
    // Verify JSON output matches expected format
  });
});
```

## Troubleshooting Guide

### Common Issues

#### Icons Not Displaying
- **Cause**: Icon component not properly imported
- **Solution**: Ensure icon exists in Lucide React library
- **Fallback**: Default to Phone icon

#### Edges Not Connecting
- **Cause**: Missing edge creation in node addition
- **Solution**: Verify setEdges is called with proper edge data

#### Configuration Panel Not Opening
- **Cause**: selectedNode state not set correctly
- **Solution**: Check onNodeClick handler implementation

### Debug Tools

#### JSON Logging
```typescript
// Real-time workflow JSON logging
useEffect(() => {
  if (nodes.length > 0) {
    const json = generateJSON();
    console.log('🔄 Current Workflow JSON:', json);
  }
}, [nodes.length, generateJSON]);
```

#### State Inspection
```typescript
// Zustand devtools integration
export const useWorkflowStore = create<WorkflowState>()(
  devtools(
    persist(/* store config */),
    { name: 'workflow-store' }
  )
);
```

## Future Enhancements

### Planned Features

1. **Drag & Drop**: Visual node repositioning
2. **Undo/Redo**: Action history management
3. **Templates**: Pre-built workflow templates
4. **Validation**: Real-time workflow validation
5. **Export/Import**: Workflow sharing capabilities

### Scalability Considerations

1. **Virtual Scrolling**: For workflows with 100+ nodes
2. **Lazy Loading**: Load node configurations on demand
3. **Caching**: Cache frequently used configurations
4. **Optimization**: Bundle splitting for better performance

## Enhanced Search Functionality

### Overview

The workflow builder implements comprehensive search functionality in both trigger and action selection modals that searches through categories AND individual options within each category, providing users with intuitive and powerful search capabilities.

### Search Architecture

#### Multi-Level Search Strategy

The search system operates on two levels:

1. **Category Level Search**: Searches category names, descriptions, and all nested options
2. **Option Level Search**: When inside a category, searches only within that category's options

#### Implementation Details

##### Trigger Selection Modal Search

```typescript
// Enhanced category filtering - searches both categories and individual triggers
const filteredCategories = categories.filter(category => {
  const searchLower = searchTerm.toLowerCase();

  // Search in category name and description
  const categoryMatch = category.name.toLowerCase().includes(searchLower) ||
                       category.description.toLowerCase().includes(searchLower);

  // Search in individual trigger options within the category
  const triggerMatch = category.triggers.some(trigger =>
    trigger.label.toLowerCase().includes(searchLower) ||
    trigger.description.toLowerCase().includes(searchLower)
  );

  return categoryMatch || triggerMatch;
});

// Filter triggers within selected category
const filteredTriggers = selectedCategoryData?.triggers.filter(trigger => {
  const searchLower = searchTerm.toLowerCase();
  return trigger.label.toLowerCase().includes(searchLower) ||
         trigger.description.toLowerCase().includes(searchLower);
}) || [];
```

##### Action Selection Modal Search

```typescript
// Enhanced category filtering - searches both categories and individual actions
const filteredCategories = categorizedActions.filter(category => {
  const searchLower = searchTerm.toLowerCase();

  // Search in category name and description
  const categoryMatch = category.name.toLowerCase().includes(searchLower) ||
                       category.description.toLowerCase().includes(searchLower);

  // Search in individual action options within the category
  const actionMatch = category.actions.some(action =>
    action.label.toLowerCase().includes(searchLower) ||
    action.description.toLowerCase().includes(searchLower)
  );

  return categoryMatch || actionMatch;
});

// Filter actions within selected category
const filteredActions = selectedCategoryData?.actions.filter(action => {
  const searchLower = searchTerm.toLowerCase();
  return action.label.toLowerCase().includes(searchLower) ||
         action.description.toLowerCase().includes(searchLower);
}) || [];
```

### Search Behavior Examples

#### Category Level Search Examples

| Search Term | Results | Reason |
|-------------|---------|---------|
| "email" | Communication category | Contains "Send Email" action |
| "form" | Forms category | Matches category name AND contains form triggers |
| "whatsapp" | Communication category | Contains "Send WhatsApp" action |
| "delay" | Communication category | Contains "Delay" action |
| "sms" | Communication category | Contains "Send SMS" action |

#### Within Category Search Examples

When inside **Communication** category:

| Search Term | Results | Description |
|-------------|---------|-------------|
| "email" | Send Email action only | Filters to email-related actions |
| "sms" | Send SMS action only | Filters to SMS-related actions |
| "message" | WhatsApp, SMS actions | Both contain "message" in description |

When inside **Forms** category:

| Search Term | Results | Description |
|-------------|---------|-------------|
| "submit" | Form submission triggers | Matches triggers with "submit" |
| "enquiry" | Product enquiry triggers | Matches specific form types |

### User Experience Flow

#### Search Flow Diagram

```
User Types Search Term
         ↓
Category Level Filtering
    ↓           ↓
Category Match   Option Match
    ↓               ↓
Show Category   Show Category
         ↓
User Clicks Category
         ↓
Option Level Filtering
         ↓
Show Filtered Options
```

#### Interaction Patterns

1. **Start Typing**: Categories appear if they contain matching options
2. **Click Category**: Navigate to filtered options within that category
3. **Continue Typing**: Further filter within the selected category
4. **Clear Search**: See all available options
5. **Navigate Back**: Search term persists for continued filtering

### Smart Empty States

The search system provides contextual empty state messages:

```typescript
// For triggers
{filteredTriggers.length === 0 && (
  <div className="text-center py-8 text-gray-500">
    {searchTerm ? 'No triggers found matching your search' : 'No triggers available in this category'}
  </div>
)}

// For actions
{filteredActions.length === 0 && (
  <div className="text-center py-8 text-gray-500">
    {searchTerm ? 'No actions found matching your search' : 'No actions available in this category'}
  </div>
)}
```

### Performance Characteristics

#### Optimization Features

1. **Case Insensitive**: All searches use `toLowerCase()` for better UX
2. **Real-time**: Results update as user types without debouncing
3. **Efficient Algorithms**: Uses `Array.filter()` and `Array.some()` for optimal performance
4. **Small Data Sets**: No performance concerns with current data volume
5. **State Persistence**: Search term maintained when navigating between views

#### Memory Usage

- Minimal memory overhead due to functional filtering approach
- No caching required for current data set sizes
- Garbage collection friendly with no persistent filter objects

### Search Implementation Best Practices

#### Code Organization

```typescript
// Centralized search logic
const createSearchFilter = (searchTerm: string) => {
  const searchLower = searchTerm.toLowerCase();

  return {
    categoryMatch: (category: Category) =>
      category.name.toLowerCase().includes(searchLower) ||
      category.description.toLowerCase().includes(searchLower),

    optionMatch: (option: Option) =>
      option.label.toLowerCase().includes(searchLower) ||
      option.description.toLowerCase().includes(searchLower)
  };
};
```

#### Error Handling

```typescript
// Safe filtering with fallbacks
const filteredOptions = selectedCategoryData?.options?.filter(option => {
  try {
    return searchFilter.optionMatch(option);
  } catch (error) {
    console.warn('Search filter error:', error);
    return true; // Show all options on error
  }
}) || [];
```

### Testing Scenarios

#### Functional Tests

1. **Basic Search**: Type "email" → Verify Communication category appears
2. **Deep Search**: Type "whatsapp" → Verify category appears due to nested option
3. **Category Navigation**: Search → Click category → Verify filtered options
4. **Empty Results**: Type "xyz123" → Verify appropriate empty message
5. **Clear Search**: Clear input → Verify all options return

#### Edge Cases

1. **Special Characters**: Search with symbols and numbers
2. **Very Long Terms**: Test with lengthy search strings
3. **Rapid Typing**: Fast input changes
4. **Unicode Characters**: International character support
5. **Empty Categories**: Categories with no options

### Future Enhancements

#### Planned Improvements

1. **Fuzzy Search**: Implement approximate string matching
2. **Search Highlighting**: Highlight matching terms in results
3. **Search History**: Remember recent searches
4. **Advanced Filters**: Filter by category, type, or other attributes
5. **Keyboard Shortcuts**: Quick search activation and navigation

#### Scalability Considerations

1. **Large Data Sets**: Implement debouncing for 1000+ options
2. **Search Indexing**: Pre-build search indices for faster lookups
3. **Virtual Scrolling**: Handle large result sets efficiently
4. **Caching**: Cache search results for repeated queries

This comprehensive documentation covers all aspects of our ActivePieces-style workflow builder implementation, from basic concepts to advanced implementation details, best practices, and the enhanced search functionality.
