# Frontend Node ID Format Implementation

## 🎯 **Overview**

The JSON constructor now uses **frontend node IDs** directly instead of generating long numbers. This matches your workflow where you want to use the actual node IDs from the React Flow canvas.

## 📋 **Updated Format (Using Frontend Node IDs)**

### **Before (Generated Numbers)**
```json
[
  {
    "id": 2833657698,
    "title": "Send SMS",
    "type": "ElementSMS",
    "child": 2174390738,
    "options": { ... }
  }
]
```

### **After (Frontend Node IDs)**
```json
[
  {
    "id": "trigger",
    "title": "New Product Enquired",
    "type": "ElementTrigger",
    "child": "send-email-action-1",
    "options": {
      "key": "product-inquired",
      "product_id": "260",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": "send-email-action-1",
    "title": "Send email `Test`",
    "type": "ElementAction",
    "child": "send-whatsapp-action-2",
    "options": {
      "key": "send-email-action",
      "init": "true",
      "email_uid": "658aaa6b2c053",
      "template": "true",
      "fromName": "David Encoder",
      "emailSubject": "Welcome to our service!"
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": "send-whatsapp-action-2",
    "title": "Action: Send WhatsApp Message",
    "type": "ElementWhatsApp",
    "child": null,
    "options": {
      "key": "send_whatsapp_message",
      "wa_template_id": "134",
      "messageContent": "Hello from WhatsApp!",
      "device": "device1",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  }
]
```

## 🔧 **Implementation Changes**

### **1. Use Frontend Node IDs**
```typescript
// ✅ Use actual frontend node ID
const nodeId = node.id; // e.g., "send-email-action-1"

// ✅ Use frontend ID for child reference
const childId = nextNode ? nextNode.id : null; // e.g., "send-whatsapp-action-2"

// ✅ Create element with frontend IDs
const element = {
  id: node.type.includes('trigger') ? 'trigger' : nodeId,
  title: this.getNodeTitle(node),
  type: this.mapNodeTypeToBackend(node.type),
  child: childId, // Frontend node ID
  options: this.buildNodeOptions(node),
  last_executed: null,
  evaluationResult: null
};
```

### **2. Condition Handling with Frontend IDs**
```typescript
// ✅ Use frontend node IDs for condition branches
if (node.type === 'condition' || node.type === 'split-condition') {
  const conditionEdges = edges.filter(edge => edge.source === node.id);
  if (conditionEdges.length >= 2) {
    const yesNode = nodes.find(n => n.id === conditionEdges[0].target);
    const noNode = nodes.find(n => n.id === conditionEdges[1].target);
    if (yesNode) element.childYes = yesNode.id; // Frontend ID
    if (noNode) element.childNo = noNode.id;   // Frontend ID
  }
}
```

## 📊 **Real-World Examples**

### **Email Action with Configuration**
```json
{
  "id": "email-node-123",
  "title": "Send email `Welcome`",
  "type": "ElementAction",
  "child": "sms-node-456",
  "options": {
    "key": "send-email-action",
    "init": "true",
    "email_uid": "welcome_template",
    "template": "true",
    "fromName": "David Encoder",
    "emailSubject": "Welcome to our service!",
    "content": "Welcome message content...",
    "replyTo": "welcome@company.com"
  },
  "last_executed": null,
  "evaluationResult": null
}
```

### **SMS Action with Configuration**
```json
{
  "id": "sms-node-456",
  "title": "Send SMS",
  "type": "ElementSMS",
  "child": "whatsapp-node-789",
  "options": {
    "key": "send-sms-action",
    "provider": "twilio",
    "messageContent": "Hello from SMS!",
    "senderName": "MyCompany"
  },
  "last_executed": null,
  "evaluationResult": null
}
```

### **WhatsApp Action with Configuration**
```json
{
  "id": "whatsapp-node-789",
  "title": "Action: Send WhatsApp Message",
  "type": "ElementWhatsApp",
  "child": "condition-node-101",
  "options": {
    "key": "send_whatsapp_message",
    "wa_template_id": "134",
    "messageContent": "Hello from WhatsApp!",
    "device": "device1",
    "init": true
  },
  "last_executed": null,
  "evaluationResult": null
}
```

### **Condition Node with If/Else**
```json
{
  "id": "condition-node-101",
  "title": "Email Opened Check",
  "type": "ElementCondition",
  "child": null,
  "options": {
    "key": "condition",
    "type": "open",
    "email": "welcome_template",
    "wait": "1 day",
    "init": true
  },
  "last_executed": null,
  "evaluationResult": null,
  "childYes": "success-action-202",
  "childNo": "retry-action-303"
}
```

## 🔄 **Real-Time Flow with Frontend IDs**

### **Node Addition**
```
User adds SMS node with ID: "sms-action-abc123"
↓
processNodeChain() called
↓
Element created:
{
  "id": "sms-action-abc123",
  "title": "Send SMS",
  "type": "ElementSMS",
  "child": null,
  "options": {
    "key": "send-sms-action"
  }
}
↓
Added to flat array
↓
POST /api/workflows with flat array
```

### **Configuration Submission**
```
User configures SMS node "sms-action-abc123"
↓
setConfig({ smsConfig: {...}, submitted: true })
↓
Element updated with config:
{
  "id": "sms-action-abc123",
  "title": "Send SMS",
  "type": "ElementSMS",
  "options": {
    "key": "send-sms-action",
    "provider": "twilio",
    "messageContent": "Hello!",
    "senderName": "MyCompany"
  }
}
↓
PUT /api/workflows/{automation_id} with updated flat array
```

## 📋 **Console Output Example**

```
🚀 === CONSTRUCTING FLAT ARRAY JSON (LEARN.JSON FORMAT) === {
  nodes: 3,
  edges: 2,
  workflowName: "My workflow"
}

📝 Added element to flat array: {
  id: "trigger",
  title: "New Product Enquired",
  type: "ElementTrigger",
  child: "email-action-123",
  hasConfig: false,
  optionsKeys: ["key", "product_id", "init"]
}

📝 Added element to flat array: {
  id: "email-action-123",
  title: "Send email `Test`",
  type: "ElementAction",
  child: "whatsapp-action-456",
  hasConfig: true,
  optionsKeys: ["key", "email_uid", "fromName", "emailSubject", "template"]
}

📝 Added element to flat array: {
  id: "whatsapp-action-456",
  title: "Action: Send WhatsApp Message",
  type: "ElementWhatsApp",
  child: null,
  hasConfig: true,
  optionsKeys: ["key", "wa_template_id", "messageContent", "device", "init"]
}

✅ === FLAT ARRAY JSON CONSTRUCTION COMPLETED === {
  timestamp: "2024-01-04T10:30:00.000Z",
  totalElements: 3,
  structure: "flat array (frontend node IDs)"
}

📋 === FINAL FLAT ARRAY JSON OUTPUT ===
[
  {
    "id": "trigger",
    "title": "New Product Enquired",
    "type": "ElementTrigger",
    "child": "email-action-123",
    "options": {
      "key": "product-inquired",
      "product_id": "260",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": "email-action-123",
    "title": "Send email `Test`",
    "type": "ElementAction",
    "child": "whatsapp-action-456",
    "options": {
      "key": "send-email-action",
      "email_uid": "658aaa6b2c053",
      "fromName": "David Encoder",
      "emailSubject": "Welcome to our service!",
      "template": "true",
      "init": "true"
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": "whatsapp-action-456",
    "title": "Action: Send WhatsApp Message",
    "type": "ElementWhatsApp",
    "child": null,
    "options": {
      "key": "send_whatsapp_message",
      "wa_template_id": "134",
      "messageContent": "Hello from WhatsApp!",
      "device": "device1",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  }
]
```

## 🎯 **Key Benefits**

1. **Frontend ID Consistency**: Uses actual React Flow node IDs
2. **Easy Debugging**: Node IDs match between frontend and backend
3. **Simplified Tracking**: No need to map generated numbers to frontend IDs
4. **Direct Reference**: `child` field directly references frontend node IDs
5. **Condition Branches**: `childYes`/`childNo` use frontend node IDs
6. **Real-Time Updates**: Configuration changes reflected immediately

## 🚀 **Backend Integration**

```typescript
// Frontend node IDs are used throughout
const json = generateJSON(); // Returns flat array with frontend IDs

// Submit to backend
POST /api/workflows
Body: [
  { "id": "trigger", "child": "email-action-123", ... },
  { "id": "email-action-123", "child": "sms-action-456", ... },
  { "id": "sms-action-456", "child": null, ... }
]

// Backend can now use frontend node IDs for tracking
{ "automation_id": "auto_123", "node_mappings": { ... } }
```

This implementation now uses **frontend node IDs** directly, making the JSON structure much cleaner and easier to work with! 🎯✨
