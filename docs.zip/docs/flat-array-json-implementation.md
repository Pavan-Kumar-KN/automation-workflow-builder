# Flat Array JSON Implementation (Learn.json Format)

## 🎯 **Overview**

The JSON constructor has been completely rewritten to match your **exact learn.json format** - a flat array structure instead of the nested object format.

## 📋 **Correct Format (Your learn.json)**

```json
[
  {
    "id": "trigger",
    "title": "New Product Enquired",
    "type": "ElementTrigger",
    "child": 853961588,
    "options": {
      "key": "product-inquired",
      "product_id": "260",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": 853961588,
    "title": "Tag contact",
    "type": "ElementOperation",
    "child": 448875612,
    "options": {
      "operation_type": "tag",
      "tags": ["Lead"]
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": 448875612,
    "title": "Action: Send WhatsApp Message",
    "type": "ElementWhatsApp",
    "child": 704667256,
    "options": {
      "key": "send_whatsapp_message",
      "after": null,
      "wa_template_id": "134",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  }
]
```

## 🔧 **Implementation Changes**

### **1. Updated Interface**
```typescript
// ✅ Now matches flat array format
export interface BackendWorkflowJSON extends Array<{
  id: string | number;
  title: string;
  type: string;
  child: number | null;
  options: {
    key: string;
    [key: string]: any;
  };
  last_executed: null;
  evaluationResult: null;
  childYes?: number;  // For conditions
  childNo?: number;   // For conditions
}> {}
```

### **2. Flat Array Construction**
```typescript
static construct(nodes: Node[], edges: Edge[]): BackendWorkflowJSON {
  const flatArray: BackendWorkflowJSON = [];
  
  // Process nodes in execution order
  const processedNodes = new Set<string>();
  
  // Find trigger nodes (starting points)
  const triggerNodes = nodes.filter(node => 
    node.type === 'trigger' || node.type.includes('trigger')
  );
  
  // Process each trigger and its chain
  triggerNodes.forEach(triggerNode => {
    this.processNodeChain(triggerNode, nodes, edges, flatArray, processedNodes);
  });
  
  return flatArray;
}
```

### **3. Node Chain Processing**
```typescript
private static processNodeChain(
  node: Node,
  nodes: Node[],
  edges: Edge[],
  flatArray: BackendWorkflowJSON,
  processedNodes: Set<string>
): void {
  // Generate element matching learn.json format
  const element = {
    id: node.type.includes('trigger') ? 'trigger' : numericId,
    title: this.getNodeTitle(node),
    type: this.mapNodeTypeToBackend(node.type),
    child: childId,
    options: this.buildNodeOptions(node),
    last_executed: null,
    evaluationResult: null
  };
  
  // Add to flat array
  flatArray.push(element);
  
  // Process next node in chain
  if (nextNode) {
    this.processNodeChain(nextNode, nodes, edges, flatArray, processedNodes);
  }
}
```

## 📊 **Configuration Storage Examples**

### **Email Action (Configured)**
```json
{
  "id": 704667256,
  "title": "Send email `Test`",
  "type": "ElementAction",
  "child": 689914840,
  "options": {
    "key": "send-email-action",
    "init": "true",
    "email_uid": "658aaa6b2c053",
    "template": "true",
    "fromName": "David Encoder",
    "emailSubject": "Welcome to our service!",
    "content": "Welcome message content..."
  },
  "last_executed": null,
  "evaluationResult": null
}
```

### **WhatsApp Action (Configured)**
```json
{
  "id": 448875612,
  "title": "Action: Send WhatsApp Message",
  "type": "ElementWhatsApp",
  "child": 704667256,
  "options": {
    "key": "send_whatsapp_message",
    "after": null,
    "wa_template_id": "134",
    "init": true,
    "messageContent": "Hello from WhatsApp!",
    "device": "device1"
  },
  "last_executed": null,
  "evaluationResult": null
}
```

### **Condition Node (If/Else)**
```json
{
  "id": 417095917,
  "title": "Email Opened Check",
  "type": "ElementCondition",
  "child": null,
  "options": {
    "key": "condition",
    "type": "open",
    "email": "658aaa6b2c053",
    "wait": "1 day",
    "init": true
  },
  "last_executed": null,
  "evaluationResult": null,
  "childYes": 1090114898,
  "childNo": 989082761
}
```

## 🔄 **Real-Time Flow**

### **Node Addition**
```
User adds SMS node
↓
processNodeChain() called
↓
Element created:
{
  "id": 2833657698,
  "title": "Send SMS",
  "type": "ElementSMS",
  "child": null,
  "options": {
    "key": "send-sms-action"
  }
}
↓
Added to flat array
↓
POST /api/workflows with flat array
```

### **Configuration Submission**
```
User configures SMS node
↓
setConfig({ smsConfig: {...}, submitted: true })
↓
processNodeChain() called again
↓
Element updated with config:
{
  "id": 2833657698,
  "title": "Send SMS",
  "type": "ElementSMS",
  "options": {
    "key": "send-sms-action",
    "provider": "twilio",
    "messageContent": "Hello!",
    "senderName": "MyCompany"
  }
}
↓
PUT /api/workflows/{automation_id} with updated flat array
```

## 📋 **Console Output Example**

```
🚀 === CONSTRUCTING FLAT ARRAY JSON (LEARN.JSON FORMAT) === {
  nodes: 3,
  edges: 2,
  workflowName: "My workflow"
}

📝 Added element to flat array: {
  id: "trigger",
  title: "New Product Enquired",
  type: "ElementTrigger",
  hasConfig: false
}

📝 Added element to flat array: {
  id: 853961588,
  title: "Action: Send WhatsApp Message", 
  type: "ElementWhatsApp",
  hasConfig: true
}

📝 Added element to flat array: {
  id: 704667256,
  title: "Send email `Test`",
  type: "ElementAction",
  hasConfig: true
}

✅ === FLAT ARRAY JSON CONSTRUCTION COMPLETED === {
  timestamp: "2024-01-04T10:30:00.000Z",
  totalElements: 3,
  structure: "flat array (learn.json format)"
}

📋 === FINAL FLAT ARRAY JSON OUTPUT ===
[
  {
    "id": "trigger",
    "title": "New Product Enquired",
    "type": "ElementTrigger",
    "child": 853961588,
    "options": {
      "key": "product-inquired",
      "product_id": "260",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": 853961588,
    "title": "Action: Send WhatsApp Message",
    "type": "ElementWhatsApp", 
    "child": 704667256,
    "options": {
      "key": "send_whatsapp_message",
      "wa_template_id": "134",
      "messageContent": "Hello from WhatsApp!",
      "device": "device1",
      "init": true
    },
    "last_executed": null,
    "evaluationResult": null
  },
  {
    "id": 704667256,
    "title": "Send email `Test`",
    "type": "ElementAction",
    "child": null,
    "options": {
      "key": "send-email-action",
      "email_uid": "658aaa6b2c053",
      "fromName": "David Encoder",
      "emailSubject": "Welcome!",
      "template": "true",
      "init": "true"
    },
    "last_executed": null,
    "evaluationResult": null
  }
]
```

## 🎯 **Key Features**

### **1. Exact Format Match** ✅
- Flat array structure (not nested object)
- Numeric IDs for actions, "trigger" for triggers
- `child` field points to next element
- `options` object contains all configuration

### **2. Configuration Extraction** ✅
- Email config → `fromName`, `emailSubject`, `content`
- SMS config → `provider`, `messageContent`, `senderName`
- WhatsApp config → `wa_template_id`, `messageContent`, `device`
- Form config → `form_builder_uid`, `init`

### **3. Condition Handling** ✅
- `childYes` and `childNo` for if/else branches
- Proper condition type mapping
- Branch processing in execution chain

### **4. Real-Time Generation** ✅
- Flat array generated on every node change
- Configuration updates reflected immediately
- Ready for backend submission

## 🚀 **Backend Integration**

```typescript
// Real-time submission
const { generateJSON, submitToBackend } = useWorkflowJSON();

// Every node change triggers this
const json = generateJSON(); // Returns flat array

// Submit to backend
POST /api/workflows
Body: [
  { "id": "trigger", "title": "...", "type": "...", ... },
  { "id": 123456, "title": "...", "type": "...", ... }
]

// Backend returns
{ "automation_id": "auto_123" }
```

This implementation now generates JSON in your **exact learn.json flat array format** with proper configuration storage and real-time updates! 🎯✨
